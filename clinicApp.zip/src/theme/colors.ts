export const colors = {
  primary: "#2F80ED",
  secondary: "#56CCF2",
  background: "#F5F7FA",
  card: "#FFFFFF",
  text: "#1F2937",
  muted: "#6B7280",
  success: "#22C55E",
  danger: "#EF4444"
};